from flask import Flask, url_for, render_template
from flask import request, redirect, jsonify, flash
from flask import session as login_session
from sqlalchemy import create_engine, inspect, func
from sqlalchemy.orm import sessionmaker
from database_setup import Base, Member, Open1, Close1, Brace
import random, os
from flask_login import LoginManager, login_user, login_required, current_user
from flask_wtf import Form
from wtforms import StringField, IntegerField, PasswordField
from wtforms.validators import DataRequired, Length, ValidationError
from flask_bcrypt import Bcrypt



app =  Flask(__name__)
app.secret_key = 'super_secret_key'
engine = create_engine('sqlite:///mydb.db', connect_args ={'check_same_thread':False}, echo = True )
Base.metadata.bind = engine
DBSession = sessionmaker(bind = engine)
session = DBSession()
login_manager = LoginManager(app)
bcrypt = Bcrypt(app)

@login_manager.user_loader
def load_user(user_id):
    return session.query(Member).filter_by(id = user_id).first()



#Main Page
@app.route('/')
def index():
    return render_template('main.html')


class LoginForm(Form):
	username = StringField('username',validators=[DataRequired("Please enter username.")])
	password = StringField('username',validators=[DataRequired("Please enter password.")])

class RegistrationForm(Form):
	name = StringField('name',validators=[DataRequired("Please enter name.")])
	coins = IntegerField('coins',validators=[DataRequired("Please enter coins.")])
	username = StringField('username',validators=[DataRequired("Please enter username within 6-12 charectors."), Length(min=6, max=12)])
	password = StringField('password',validators=[DataRequired("Please enter password within 6-12 charectors."), Length(min=6, max=12)])
	trans_id = StringField('trans_id',validators=[DataRequired("Please enter transaction id.")])
	# mobile = IntegerField('mobile',[validators.DataRequired("Please enter mobile number having 10 digits."), validators.Length(min=10, max=10)])

	def validate_username(self,username):
		user = session.query(Member).filter_by(username = username.data).first()
		if user:
			raise ValidationError('username already existed,damu')

	# def validate_trans_id(self,trans_id):
	# 	user = session.query(Member).filter_by(trans_id = trans_id.data).first()
	# 	if user:
	# 		raise ValidationError('transaction id  already existed')

	# def validate_mobile(self,username):
	# 	user = session.query(Member).filter_by(mobile = mobile.data).first()
	# 	if user:
	# 		raise ValidationError('mobile number already existed')

session.rollback()

class AdminLogin(Form):
	username = StringField('username',validators=[DataRequired("Please enter username.")])
	password = StringField('username',validators=[DataRequired("Please enter password.")])

@app.route('/add/user',methods = ['GET','POST'])
def addUser():
	form = RegistrationForm()
	# if form.validate_on_submit()  and login_session['user_ex_yes']:
	if request.method == 'POST' and login_session['user_ex_yes']:
		name = form.name.data
		username = form.username.data
		# if session.query(Member).filter_by(username = username).first():
		# 	raise ValidationError("Username already exists")
		password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
		trans_id = form.trans_id.data
		coins = form.coins.data
		data = Member(name = name, username = username, password = password, trans_id = trans_id, coins = coins)
		session.add(data)
		session.commit()
		print(form.errors)
		return "user created succesfully"
		return render_template('admin.html')
	else:
		return render_template('add_user.html', form = form, errors = form.errors)


@app.route('/admin/login', methods = ['GET','POST'])
def adminLogin():
	form1 = AdminLogin()
	if request.method == 'POST':
		if form.username.data == "game" and form.password.data == "play":
			login_session['user_ex_yes'] = True
			return "admin loged-in succesfully"
			return render_template("admin.html") 
	else:
		return render_template('admin_login.html',form = form1)




@app.route('/user_login', methods = ['GET','POST'])
def userLogin():
	form2 = LoginForm()
	if request.method == 'POST':
		user = session.query(Member).filter_by(username = form.username.data).first()
		if user.password == bcrypt.generate_password_hash(form.password.data).decode('utf-8'):
			login_user(user)
			return "you are succesfully loged in"
	else:
		return render_template("user_login.html", form = form2)


if __name__ == '__main__':
    app.debug = True
    # app.run()
    app.run(host='0.0.0.0',port=8000)
