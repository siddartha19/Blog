from sqlalchemy import Integer, String, Column, ForeignKey, Boolean, Date
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import create_engine
from flask_login import UserMixin

Base= declarative_base()


class Member(Base, UserMixin):
	__tablename__ = "member"
	id = Column(Integer, primary_key = True)
	name = Column(String(50), nullable = False)
	coins = Column(Integer, nullable = False)
	username = Column(String(20), unique = True, nullable = False)
	password = Column(String(20), nullable = False)
	trans_id = Column(String(50), unique = True, nullable = False)
	# mobile = Column(Integer, unique = True, nullable = False)

class Open1(Base):
	__tablename__ = "open1"
	id = Column(Integer, primary_key = True)
	num = Column(Integer, nullable = False)
	amount = Column(Integer, nullable = False)
	g_type = Column(String(50), nullable = False)
	member_id = Column(Integer, ForeignKey('member.id'))
	member = relationship(Member)


class Close1(Base):
	__tablename__ = "close1"
	id = Column(Integer, primary_key = True)
	num = Column(Integer, nullable = False)
	amount = Column(Integer, nullable = False)
	g_type = Column(String(50), nullable = False)
	member_id = Column(Integer, ForeignKey('member.id'))
	member = relationship(Member)

class Brace(Base):
	__tablename__ = "brace"
	id = Column(Integer, primary_key = True)
	num = Column(Integer, nullable = False)
	amount = Column(Integer, nullable = False)
	g_type = Column(String(50), nullable = False)
	member_id = Column(Integer, ForeignKey('member.id'))
	member = relationship(Member)


engine = create_engine('sqlite:///mydb.db')
Base.metadata.create_all(engine)
